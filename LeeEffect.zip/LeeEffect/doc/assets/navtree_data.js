var NAVTREE_DATA =
[ [ "de.noXi.leeeffect", "de/noXi/leeeffect/package-summary.html", [ [ "Classes", null, [ [ "MainActivity", "de/noXi/leeeffect/MainActivity.html", null, "" ], [ "VisualizerView", "de/noXi/leeeffect/VisualizerView.html", null, "" ] ]
, "" ] ]
, "" ] ]

;

